//
//  ASCityCell.h
//  ITotem
//
//  Created by qiuyan on 15-4-3.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASCityModel.h"

@interface ASCityCell : UITableViewCell

- (void)setContentCell:(ASCityModel *)model;
- (void)setLocationimgShow;


@end
