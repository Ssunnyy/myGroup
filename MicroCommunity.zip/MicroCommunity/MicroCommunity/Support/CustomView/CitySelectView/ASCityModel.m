//
//  ASCityModel.m
//
//
//  Created by qiuyan on 15-4-3.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import "ASCityModel.h"

@implementation ASCityModel

- (NSDictionary *)attributeMapDictionary {
    return @{
             @"cityCn":@"cityCn",
             @"cityCode":@"cityCode",
             @"pinYin":@"pinYin"
             };
}

@end
