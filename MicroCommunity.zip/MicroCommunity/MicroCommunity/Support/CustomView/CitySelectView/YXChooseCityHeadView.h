//
//  YXChooseCityHeadView.h
//  YiXin
//
//  Created by qiuyan on 14-12-2.
//  Copyright (c) 2014年 com.yixin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchBarView.h"

@interface YXChooseCityHeadView : UIView
@property (nonatomic, strong) SearchBarView *searchView;
@end
