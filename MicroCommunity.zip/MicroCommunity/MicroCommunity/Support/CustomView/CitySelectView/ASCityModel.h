//
//  ASCityModel.h
//  ITotem
//
//  Created by qiuyan on 15-4-3.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import "ITTBaseModelObject.h"
@interface ASCityModel : ITTBaseModelObject
@property (nonatomic, strong) NSString *cityCn;
@property (nonatomic, strong) NSString *cityCode;
@property (nonatomic, strong) NSString *pinYin;

@end
