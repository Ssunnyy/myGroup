//
//  ITTUserDefaultCacheDao.h
//  iTotemFrame
//
//  Created by Sword on 13-9-6.
//  Copyright (c) 2013年 iTotemStudio. All rights reserved.
//

#import "ITTCacheDao.h"

@interface ITTUserDefaultCacheDao : ITTCacheDao

@end
