//
//  MMTagModel.h
//  Mimi
//
//  Created by wangjiangjiao on 14-6-5.
//
//

#import "ITTBaseModelObject.h"

@interface MMTagModel : ITTBaseModelObject

@property (nonatomic , strong) NSString * tagID;
@property (nonatomic , strong) NSString * tagName;


@end
