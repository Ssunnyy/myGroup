//
//  UIFont+ITTAdditions.hiTotemFrame
//  iTotemFrame
//
//  Created by Rainbow on 9/18/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UIFont (ITTAdditions) 

- (CGFloat)ittLineHeight;

@end
