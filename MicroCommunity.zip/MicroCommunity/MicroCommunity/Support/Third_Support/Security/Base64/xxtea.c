/*********************************************************************************
 *	Author: Dare Fish
 *  Version: 1.0
 *  Filename: xxtea.c
 *
 *
 *  Copyright (c) Wednesday, February 13, 2008 Dare Fish.
 *
 *
 ********************************************************************************/

#include "xxtea.h"
#include <stdlib.h>
#include <string.h>
xxtea_long *xxtea_to_long_array(unsigned char *data, xxtea_long len, int include_length, xxtea_long *ret_len);
unsigned char *xxtea_to_byte_array(xxtea_long *data, xxtea_long len, int include_length, xxtea_long *ret_len);



static void xxtea_long_encrypt(xxtea_long *v, xxtea_long len, xxtea_long *k);
static void xxtea_long_decrypt(xxtea_long *v, xxtea_long len, xxtea_long *k);
static unsigned char *_encrypt(unsigned char *data, xxtea_long len, unsigned char *key, xxtea_long *ret_len);
static unsigned char *_decrypt(unsigned char *data, xxtea_long len, unsigned char *key, xxtea_long *ret_len);
static xxtea_long ustrlen(unsigned char *ustr);

unsigned char *xxtea_encrypt(unsigned char *data, unsigned char *key, int *len)
{
    unsigned char *result;
    xxtea_long data_len, key_len, ret_length;

	data_len = ustrlen(data);
	key_len = ustrlen(key);

	if(data_len == 0) return NULL;
    if(key_len == 0) return NULL;
    result = _encrypt(data, data_len, key, &ret_length);
	*len = (int) ret_length;
    if(result != NULL) {
		return result;
    } else {
        return NULL;
    }
}

unsigned char *xxtea_decrypt(unsigned char *data, unsigned char *key, int len)
{
    unsigned char *result;
    xxtea_long data_len, key_len, ret_length;

	data_len = (xxtea_long) len;
	key_len = ustrlen(key);

	if(data_len == 0) return NULL;
    if(key_len == 0) return NULL;
    result = _decrypt(data, data_len, key, &ret_length);
    if(result != NULL) {
		return result;
    } else {
        return NULL;
    }
}

xxtea_long *xxtea_to_long_array(unsigned char *data, xxtea_long len, int include_length, xxtea_long *ret_len) {
    xxtea_long i, n, *result;
	n = len >> 2;
    n = (((len & 3) == 0) ? n : n + 1);
    if (include_length) {
        result = (xxtea_long *) malloc((n + 1) << 2);
        result[n] = len;
	    *ret_len = n + 1;
	} else {
        result = (xxtea_long *) malloc(n << 2);
	    *ret_len = n;
    }
	memset(result, 0, n << 2);
	for (i = 0; i < len; i++) {
        result[i >> 2] |= (xxtea_long)data[i] << ((i & 3) << 3);
    }
    return result;
}

unsigned char *xxtea_to_byte_array(xxtea_long *data, xxtea_long len, int include_length, xxtea_long *ret_len) {
    xxtea_long i, n, m;
    unsigned char *result;
    n = len << 2;
    if (include_length) {
        m = data[len - 1];
        if ((m < n - 7) || (m > n - 4)) return NULL;
        n = m;
    }
    result = (unsigned char *) malloc(n + 1);
	for (i = 0; i < n; i++) {
        result[i] = (unsigned char)((data[i >> 2] >> ((i & 3) << 3)) & 0xff);
    }
	result[n] = '\0';
	*ret_len = n;
	return result;
}

unsigned char *_encrypt(unsigned char *data, xxtea_long len, unsigned char *key, xxtea_long *ret_len) {
    unsigned char *result;
    xxtea_long *v, *k, v_len, k_len;
    v = xxtea_to_long_array(data, len, 1, &v_len);
    k = xxtea_to_long_array(key, ustrlen(key), 0, &k_len);
    xxtea_long_encrypt(v, v_len, k);
    result = xxtea_to_byte_array(v, v_len, 0, ret_len);
    free(v);
    free(k);
    return result;
}

unsigned char *_decrypt(unsigned char *data, xxtea_long len, unsigned char *key, xxtea_long *ret_len) {
    unsigned char *result;
    xxtea_long *v, *k, v_len, k_len;
    v = xxtea_to_long_array(data, len, 0, &v_len);
    k = xxtea_to_long_array(key, ustrlen(key), 0, &k_len);
    xxtea_long_decrypt(v, v_len, k);
    result = xxtea_to_byte_array(v, v_len, 1, ret_len);
    free(v);
    free(k);
    return result;
}

void xxtea_long_encrypt(xxtea_long *v, xxtea_long len, xxtea_long *k) {
    xxtea_long n = len - 1;
    xxtea_long z = v[n],p, q = 6 + 52 / (n + 1), sum = 0, e;
    if (n < 1) {
        return;
    }
    xxtea_long  y = v[0];
    while (0 < q--) {
        sum += XXTEA_DELTA;
        e = sum >> 2 & 3;
        for (p = 0; p < n; p++) {
            y = v[p + 1];
            z = v[p] += XXTEA_MX;
        }
        y = v[0];
        z = v[n] += XXTEA_MX;
    }
}

void xxtea_long_decrypt(xxtea_long *v, xxtea_long len, xxtea_long *k) {
    xxtea_long n = len - 1;
    xxtea_long y = v[0], p, q = 6 + 52 / (n + 1), sum = q * XXTEA_DELTA, e;
    if (n < 1) {
        return;
    }
    xxtea_long z = v[n];
    while (sum != 0) {
        e = sum >> 2 & 3;
        for (p = n; p > 0; p--) {
            z = v[p - 1];
            y = v[p] -= XXTEA_MX;
        }
        z = v[n];
        y = v[0] -= XXTEA_MX;
        sum -= XXTEA_DELTA;
    }
}

xxtea_long ustrlen(unsigned char *s)
{
    unsigned char *ptr = s;
    while(*s) s++;
    return (xxtea_long) (s - ptr);
}

