//
//  UIImage+Helpers.h
//  ITotem
//
//  Created by Mac on 15/5/7.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Helpers)
//通过颜色生成相应的图片
+ (UIImage *)createImageWithColor:(UIColor *)color;

@end
