//
//  AppDelegate.m
//  ITotem
//
//  Created by qiuyan on 15-3-2.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import "AppDelegate.h"
#import "ITTCustomTabBarView.h"
#import "ITTHiddenTabBarViewController.h"
#import "ASMainViewController.h"
#import "ASIMViewController.h"
#import "ASMyViewController.h"
#import "ASSearchViewController.h"
#import "ASLoginViewController.h"
#import "ASSearchRequestManager.h"

@interface AppDelegate()
{
    ITTCustomTabBarView                 *_customTabBarView;
    ITTHiddenTabBarViewController       *_tabbarController;

}
@property (nonatomic, retain) BaseViewController* currentViewController;

/**
 *  tab
 */

@end

#pragma mark - Public Methods
AppDelegate *_appDelegate;
BOOL iscustomTabBarViewHide = NO;

@implementation AppDelegate

+ (void)HideTabBar
{
    if (!iscustomTabBarViewHide) {
        iscustomTabBarViewHide = YES;
        [UIView animateWithDuration:0.3 animations:^{
            _appDelegate.customTabBarView.frametop = SCREEN_HEIGHT;
        }];
    }
}
+ (void)DisplayTabBar
{
    if (iscustomTabBarViewHide) {
        iscustomTabBarViewHide = NO;
        [UIView animateWithDuration:0.3 animations:^{
            _appDelegate.customTabBarView.frametop = SCREEN_HEIGHT - _appDelegate.customTabBarView.frameheight;
        }];
    }
}

+ (AppDelegate *)GetAppDelegate {
    return _appDelegate;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    /**
     *  注册通知
     */
    [self registNotification];
    /**
     *  viewDidLoad中基本方法
     */
    _appDelegate = self;
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    /**
     *  初始化控制器和添加用户在其他客户端登陆后当前用户被顶下去
     *
     *  @param setUpTabbarController
     *
     *  @return
     */
    [self performSelector:@selector(setUpTabbarController) withObject:self afterDelay:.1f];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setUpLoginView) name:@"PostLogin" object:nil];
    /**
     *  将用户经纬度上传到服务器
     */
    [self updatePostion];
    
    return YES;
}

/**
 *  注册通知
 */
- (void) registNotification{

    // 设置群组信息提供者。
    double version = [[[UIDevice currentDevice] systemVersion]floatValue];
    if (version >= 8.0) {
        // 在 iOS 8 下注册苹果推送，申请推送权限。
        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeBadge
                                                                                             |UIUserNotificationTypeSound
                                                                                             |UIUserNotificationTypeAlert) categories:nil];
        [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
    }
    else {
        // 注册苹果推送，申请推送权限。
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeSound];
    }

    
}

#pragma mark - 定位
#pragma mark 更新用户自身位置

- (void)updatePostion
{
    NSMutableDictionary * param = [NSMutableDictionary dictionaryWithCapacity:1];
    if ([self checkLocationIsValid]) {
        [[MMLocationManager shareLocation]startGetUserLocation:^(CLLocationCoordinate2D locationCorrrdinate)
         {
             NSString *_lon=[NSString stringWithFormat:@"%f",locationCorrrdinate.longitude];
             NSString *_lat=[NSString stringWithFormat:@"%f",locationCorrrdinate.latitude];
             
             [USER_DEFAULT setObject:_lon forKey:MMLastLongitude];
             [USER_DEFAULT setObject:_lat forKey:MMLastLatitude];

             [param safeString:[NSString stringWithFormat:@"%f",locationCorrrdinate.longitude] ForKey:@"lon"];
             [param safeString:[NSString stringWithFormat:@"%f",locationCorrrdinate.latitude] ForKey:@"lat"];
             if ([[UserManager shareManager] isAutoLoginResult]) {
                 [param safeString:[[UserManager shareManager] getCurrentUser].userId ForKey:@"appUserId"];

             }
             [[ASSearchRequestManager shareManager] requestUserSavePositionWithParam:param withIndicatorView:nil withCancelRequestID:@"savePostion" withHttpMethod:kHTTPMethodPost onRequestFinish:^(MKNetworkOperation *operation) {
                 
                 if ([operation isSuccees]) {
                     
                 }
             } onRequestFailed:^(MKNetworkOperation *operation, NSError *error) {
                 
             }];
         }];
    }
}

#pragma mark 是否开启定位功能
-(BOOL)checkLocationIsValid
{
    if ([CLLocationManager locationServicesEnabled] &&
        ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorized
         || [CLLocationManager authorizationStatus] == kCLAuthorizationStatusNotDetermined)) {
            //定位功能可用，开始定位
            
            return YES;
        }
    else if ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusDenied){
        
        return NO;
    }
    return NO;
}

#pragma mark - 初始化控制器

- (void)setUpTabbarController
{
    _tabbarController = [[ITTHiddenTabBarViewController alloc] init];
    NSMutableArray *navControllers = [NSMutableArray array];
    [self addViewController:[ASMainViewController class] toArray:navControllers];
    [self addViewController:[ASSearchViewController class] toArray:navControllers];
    [self addViewController:[ASIMViewController class] toArray:navControllers];
    [self addViewController:[ASMyViewController class] toArray:navControllers];
    
    _tabbarController.viewControllers = navControllers;
    self.window.rootViewController = _tabbarController;
    _customTabBarView = [ITTCustomTabBarView loadFromXib];
    _customTabBarView.framewidth = SCREEN_WIDTH;
    _customTabBarView.frametop = SCREEN_HEIGHT - _customTabBarView.frameheight;
    [_customTabBarView selectTabAtIndex:0];
    _customTabBarView.tabBarController = _tabbarController;
    [_tabbarController.view addSubview:_customTabBarView];
}

- (void)addViewController:(Class)ViewController toArray:(NSMutableArray*)array{
    UIViewController *vc = [[ViewController alloc] init];
    UINavigationController *nvc = [[UINavigationController alloc] initWithRootViewController:vc];
  //  [nvc setNavigationBarHidden:YES];
    [array addObject:nvc];
}

-(void)getCurrentController:(BaseViewController*)controller
{
    if (controller) {
        self.currentViewController = (BaseViewController*)controller;
    }
}
/**
 *  用户在其他客户端登陆以后发送通知踢出当前用户
 */
- (void)setUpLoginView
{
    [ITTPromptView showMessage:@"请重新登录"];
    [USER_DEFAULT setBool:NO forKey:ALLOW_AUTOLOGIN];
    ASLoginViewController *loginVc = [[ASLoginViewController alloc] initWithNibName:@"ASLoginViewController" bundle:nil];
    loginVc.enterType = LoginEnterTypeOther;
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:loginVc];
    loginVc.currentController = self.currentViewController;
    [self.currentViewController presentViewController:nav animated:YES completion:nil];
}
							
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // 每次打开应用就更新地理坐标
    [self updatePostion];
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

# pragma mark - IM
#ifdef __IPHONE_8_0
- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings
{
    // Register to receive notifications.
    [application registerForRemoteNotifications];
}

- (void)application:(UIApplication *)application handleActionWithIdentifier:(NSString *)identifier forRemoteNotification:(NSDictionary *)userInfo completionHandler:(void(^)())completionHandler
{
    
}
#endif

// 获取苹果推送权限成功。
-(void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{

}

-(void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
}
//  支付宝客户端返回
- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation {
    
    return  YES;
}
@end
