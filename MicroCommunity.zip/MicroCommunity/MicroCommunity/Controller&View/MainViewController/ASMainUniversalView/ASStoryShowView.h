//
//  ASStoryShowView.h
//  ITotem
//
//  Created by qiuyan on 15-3-12.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASStoryShowView : UIView

- (void)changeNum:(NSString *)num;
- (void) setContent:(NSString *) contetn;
@end
