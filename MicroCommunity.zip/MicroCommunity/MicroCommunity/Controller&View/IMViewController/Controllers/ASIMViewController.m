//
//  ASIMViewController.m
//  ITotem
//
//  Created by Mac on 15/3/30.
//  Copyright (c) 2015年 李超峰. All rights reserved.
//

#import "ASIMViewController.h"

@interface ASIMViewController ()

@end

@implementation ASIMViewController

#pragma mark  ---  取消请求

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:YES];
}

- (void)viewWillAppear:(BOOL)animated {

    [super viewWillAppear:animated];
}
-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

@end

