//
//  ASIMViewController.h
//  ITotem
//
//  Created by Mac on 15/3/30.
//  Copyright (c) 2015年 李超峰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASIMViewController : UIViewController

@end
