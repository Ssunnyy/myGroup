//
//  ASResetPassViewController.h
//  ITotem
//
//  Created by adims on 15/3/20.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface ASResetPassViewController : BaseViewController

@property (nonatomic,assign) int type; // tyep 1 忘记密码 2.忘记支付密码

@end
