//
//  ASSearchViewController.m
//  ITotem
//
//  Created by qiuyan on 15-3-3.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import "ASSearchViewController.h"
#import "ASSearchRequestManager.h"

@interface ASSearchViewController ()
@property (strong, nonatomic) IBOutlet UIImageView *_searchImageView;
@end

@implementation ASSearchViewController

- (void)viewWillAppear:(BOOL)animated {

    [super viewWillAppear:YES];
    [AppDelegate DisplayTabBar];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setNav];
    // 读取职业数据
}

- (void) setNav{

    [self setButtonStyle:UIButtonStyleRegister andImage:ImageNamed(@"sosuo") highImage:ImageNamed(@"sosuo")];
    
}

@end
