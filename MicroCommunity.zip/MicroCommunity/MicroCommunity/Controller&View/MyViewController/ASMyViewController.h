//
//  ASMyViewController.h
//  ITotem
//
//  Created by qiuyan on 15-3-3.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import "BaseViewController.h"

@interface ASMyViewController : BaseViewController

@end
