//
//  ASOrderDetailViewController.m
//  aisuo
//
//  Created by qiuyan on 15-3-26.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import "ASOrderDetailViewController.h"
#import "ASOrderReturnMoneyViewController.h"
#import "ASOrderAppraisalViewController.h"


@interface ASOrderDetailViewController ()<UIWebViewDelegate>

{
        UIActivityIndicatorView *activityIndicatorView;
}
@property (nonatomic, retain) UIWebView *webView;

@end

@implementation ASOrderDetailViewController

- (void) viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:YES];
    [AppDelegate HideTabBar];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setNavigationBarStatus];
    [self setUpWebView];
}

/**
 *  设置导航栏
 */
- (void)setNavigationBarStatus
{
    [self setNavigationBarTitle:@"订单详情"];
    [self setButtonStyle:UIButtonStyleBack andImage:ImageNamed(@"back_icon_.png") highImage:ImageNamed(@"back_pre.png")];
    [self setButtonStyle:UIButtonStyleRight andImage:ImageNamed(@"back_icon_.png") highImage:ImageNamed(@"back_pre.png")];
    
}

- (void)setUpWebView
{
    _webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, SCREEN_HEIGHT - 64)];
    self.webView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_webView];
    self.webView.delegate = self;
    
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.orderDetailUrl]]];
    
    activityIndicatorView = [[UIActivityIndicatorView alloc]
                             initWithFrame : CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)] ;
    [activityIndicatorView setCenter: self.view.center] ;
    [activityIndicatorView setActivityIndicatorViewStyle: UIActivityIndicatorViewStyleGray] ;
    [self.view addSubview : activityIndicatorView] ;

}

#pragma  mark  --  网页delegate

#pragma mark---UIWebViewDelegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    
    NSString *urlStr = [request.URL absoluteString] ;
    NSMutableString *url = [NSMutableString stringWithString:urlStr];
    //  订单详情
    //  CC退款
    if ([urlStr hasPrefix:@"type:cctk"]) {
        ASOrderReturnMoneyViewController *order = [[ASOrderReturnMoneyViewController alloc]init];
        
        NSString *absUrl = [url stringByReplacingOccurrencesOfString:@"type:cctk" withString:OrderUrl];
        order.orderDetailUrl = absUrl;
        [self.navigationController pushViewController:order animated:YES];
    }
    if ([urlStr hasPrefix:@"type:ccpj"]) {
        ASOrderAppraisalViewController *order = [[ASOrderAppraisalViewController alloc]init];
        
        NSString *absUrl = [url stringByReplacingOccurrencesOfString:@"type:ccpj" withString:OrderUrl];
        order.inType = 2;
        order.orderDetailUrl = absUrl;
        [self.navigationController pushViewController:order animated:YES];
    }
    
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [activityIndicatorView startAnimating];
    
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [activityIndicatorView stopAnimating];
    
    
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void) leftBarButtonClick:(id)sender {

    if ([_webView canGoBack]) {
        [_webView goBack];
    }else {
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}



@end
