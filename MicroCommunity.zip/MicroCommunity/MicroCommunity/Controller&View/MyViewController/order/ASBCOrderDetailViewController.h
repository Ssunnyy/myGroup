//
//  ASOrderDetailViewController.h
//  aisuo
//
//  Created by qiuyan on 15-3-26.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import "BaseViewController.h"

#pragma  mark  --  订单详情

@interface ASOrderDetailViewController : BaseViewController

@property (nonatomic , strong) NSString *orderDetailUrl;

@end
