//
//  ASMyViewController.m
//  ITotem
//
//  Created by qiuyan on 15-3-3.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import "ASMyViewController.h"
#import "ASLoginViewController.h"
#import "UIImageView+ITTAddtions.h"
#import "ITTImagePickView.h"
#import "VPersonalActionView.h"
#import "ASMyRequestManager.h"
#import "ASMainRequestManager.h"

@interface ASMyViewController ()<VActionViewDelegate,ITTImagePickDelegate,UIScrollViewDelegate>
{
    /**
     *  认证的view
     */
    IBOutlet UIView *authView;
    //认证lab
    IBOutlet UILabel *authLab;
    //判断是不是选择的背景图片
    BOOL isAlbum;

}

/**
 *  头像  头像背景
 */
@property (weak, nonatomic) IBOutlet UIView *headBgView;
@property (weak, nonatomic) IBOutlet UIView *headVIew;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *sexHeightSpace;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *sexHoriSpace;
//  head宽度
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *headWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *headHeight;
//  最底层view高度
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *viewHeight;

/**
 *  认证view 的高度
 */
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *confirmViewHeight;

/**
 *  headImgBgHeight
 */
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *headBgImgHeight;
/**
 *  收藏的新人view的宽
 */
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *personWidth;
/**
 *  订单状态view的款
 */
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *orderStatusWidth;
/**
 *  头像
 */
@property (strong, nonatomic) IBOutlet UIImageView *headImgV;
/**
 *  背景
 */
@property (weak, nonatomic) IBOutlet UIImageView *bgImageView;

@property (weak, nonatomic) IBOutlet UIImageView *waitForPay;

/**
 *  性别
 */
@property (strong, nonatomic) IBOutlet UIImageView *sexImgV;
/**
 *  昵称
 */
@property (nonatomic, strong) IBOutlet UILabel *nickLab;
/**
 *  收藏lab
 */
@property (weak, nonatomic) IBOutlet UILabel *collectLab;
/**
 *  新人lab
 */
@property (weak, nonatomic) IBOutlet UILabel *personLab;
/**
 *  我的图片lab
 */
@property (weak, nonatomic) IBOutlet UILabel *picLab;
/**
 *  待确认
 */
@property (weak, nonatomic) IBOutlet UIButton *confirmBtn;
/**
 *  售后
 */
@property (weak, nonatomic) IBOutlet UIButton *helpBtn;
/**
 *  代付款
 */
@property (weak, nonatomic) IBOutlet UIButton *unpayBtn;
/**
 *  待服务
 */
@property (weak, nonatomic) IBOutlet UIButton *serviceBtn;
/**
 *  待评价
 */
@property (weak, nonatomic) IBOutlet UIButton *commentBtn;

@property (nonatomic, strong) ASLoginViewController *loginVC;


/**
 *  actionView
 */
@property (nonatomic, strong) VPersonalActionView *actionViews;
/**
 *  拍照或是选择照片的类的实例
 */
@property (nonatomic,strong) ITTImagePickView *imagePickerView;

//背景大图
@property (nonatomic, strong) UIImage *bgBigImage;
@property (nonatomic, strong) NSString *bgBigImageKey;
//头像大图
@property (nonatomic, strong) UIImage *headBigImage;
@property (nonatomic, strong) NSString *headBigImageKey;

@property (nonatomic, strong) NSString *qiniuToken;

@property (nonatomic, strong)UIImageView *backImageView; //背景
@end

@implementation ASMyViewController

- (void)viewDidLoad
{
    
    
    [super viewDidLoad];
    [self setNavBarStatus];
    [self setUpNotification];
    [self setPersonActionView];
    
    CGFloat ImageHeight  = 0.0;
    CGFloat ImageWidth  = SCREEN_WIDTH;
    if (iPhone6) {
        ImageHeight = 330;
    }else if (iPhone6Plus){
        ImageHeight = 335;
    }else {
        ImageHeight  = 258.0;
    }
    
     self.scrollView.delegate= self;
    _backImageView = [[UIImageView alloc]init];
    _backImageView.frame = CGRectMake(0, 0, ImageWidth, ImageHeight);
    self.bgImageView.hidden = YES;
    [self.view addSubview:self.backImageView];
    [self.view addSubview:_scrollView];
    
    UIView *bgView = [[UIView alloc]initWithFrame:self.bgImageView.frame];
    [self.scrollView addSubview:bgView];
    UITapGestureRecognizer *bgTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapBGView:)];
    [bgView addGestureRecognizer:bgTap];
    
    UIView *headView = [[UIView alloc]initWithFrame:_headVIew.frame];
    headView.center = bgView.center;
    [self.scrollView  addSubview:headView];
    UITapGestureRecognizer *headTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapHeadView:)];
    [headView addGestureRecognizer:headTap];
}
#pragma mark -- 头部视图拉伸
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [self updateImg];
}
//头部视图拉伸比例
- (void)updateImg {
    CGFloat yOffset   = _scrollView.contentOffset.y;
    
    CGFloat ImageHeight  = 0.0;
    CGFloat ImageWidth  = SCREEN_WIDTH;
    if (iPhone6) {
        ImageHeight = 330;
    }else if (iPhone6Plus){
        ImageHeight = 335;
    }else {
        ImageHeight  = 258.0;
    }
    
    if (yOffset < 0) {
        
        CGFloat factor = ((ABS(yOffset)+ImageHeight)*ImageWidth)/ImageHeight;
        CGRect f = CGRectMake(-(factor-ImageWidth)/2, 0, factor, ImageHeight+ABS(yOffset));
        self.backImageView.frame = f;
    } else {
        CGRect f = self.backImageView.frame;
        f.origin.y = -yOffset;
        self.backImageView.frame = f;
    }
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [AppDelegate DisplayTabBar];
    [self senderRequest];
    
}

- (void)viewWillAppear:(BOOL)animated {

    [super viewWillAppear:YES];
    [self setAdaptionScreen];
    
}

#pragma  mark  ---  发起网络请求

- (void) senderRequest {
    
    [self setViewStyle];
    if (![[UserManager shareManager] isAutoLoginResult]) {
        [self setLoginView];
    }else{
        [self setUpData];
        [self performSelector:@selector(sendRequest) withObject:nil afterDelay:0.02];
        [self requestQiniuToken];
        if (_loginVC) {
            [_loginVC removeFromParentViewController];
            [_loginVC.view removeFromSuperview];
            _loginVC = nil;
        }
    }
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [[ASMyRequestManager shareManager] cancelAllRequest];
    [[ASMainRequestManager shareManager]cancelAllRequest];
}

/**
 *  屏幕适配
 */
- (void)setAdaptionScreen
{
    float width = SCREEN_WIDTH/3.0;
    _personWidth.constant = width;
    
    float orderWidth = SCREEN_WIDTH/5.0;
    _orderStatusWidth.constant = orderWidth;
    
    if (iPhone6Plus) {
        
        _viewHeight.constant = 830;
        _headBgImgHeight.constant = 335;
        
        _sexHeightSpace.constant = 17;
        _sexHoriSpace.constant = 17;
        
        _headHeight.constant = 120;
        _headWidth.constant = 120;
        [_headBgView makeCornerRadius:50];
        [_headVIew makeCornerRadius:50];
        [_headImgV makeCornerRadius:46];
    }else if(iPhone6){
        
        _viewHeight.constant = 800;
        
        _headBgImgHeight.constant = 303;
        
        _sexHeightSpace.constant = 15;
        _sexHoriSpace.constant = 15;
        
        _headHeight.constant = 110;
        _headWidth.constant = 110;
        
        [_headBgView makeCornerRadius:45];
        [_headVIew makeCornerRadius:45];
        [_headImgV makeCornerRadius:41];
        
    }else {
        _headBgImgHeight.constant = 258;
        
        [_headBgView makeCircleView];
        [_headVIew makeCircleView];
        [_headImgV makeCircleView];
    }


    
    //更换背景图和头像
    [_backImageView addTapGesture:^(UIImageView *imageView) {
        
    }];
    
    [_headImgV addTapGesture:^(UIImageView *imageView) {
        
        switch (imageView.tag) {
            case 200:
            {
                isAlbum = YES;
            }
                break;
            case 201:
            {
                isAlbum = NO;
            }
                break;
            default:
                break;
        }
        [self showActionView];
    }];
}
#pragma mark -- 手势
- (void)tapHeadView:(UITapGestureRecognizer *)tap{
    isAlbum = NO;
    [self showActionView];
}
- (void)tapBGView:(UITapGestureRecognizer *)tap{
    isAlbum = YES;
    [self showActionView];
}


#pragma  mark  --  VPersonalActionView
- (void) setPersonActionView {
    _actionViews = [VPersonalActionView getVPersonalActionView];
    _actionViews.actionDelegate =self;
    NSArray *arr = @[@"从相册中选择",@"拍摄",@"取消"];
    [_actionViews setUpBtnTitle:arr];
}

- (void) showActionView {
    
    [_actionViews showActionView];
}

- (void)setUpData
{
    NSString *sex = [CommonHelp changeStr:[[UserManager shareManager] getCurrentUser].gender];
    NSString *love = [[UserManager shareManager] getCurrentUser].loverNickname;
    NSString *nickName = [[UserManager shareManager] getCurrentUser].nickname;
    
    NSString *type = [[UserManager shareManager] getCurrentUser].type;
    
    
    if ([type isEqualToString:@"1"]) {
        _waitForPay.image = ImageNamed(@"icon2");
    }else if([type isEqualToString:@"2"]){
        _waitForPay.image = ImageNamed(@"iconshoukuan");
    }
    
    _sexImgV.hidden = NO;
    [_nickLab contentTest:nickName];
    if ([sex isEqualToString:@"0"]) {//男
        _sexImgV.image = [UIImage imageNamed:@"boy_"];
        if (love != nil && ![love isKindOfClass:[NSNull class]]) {
            if (love.length > 0) {
                _nickLab.text = [NSString stringWithFormat:@"%@&%@",nickName,love];
                _sexImgV.image = [UIImage imageNamed:@"fuqi"];
            }else {
                [_nickLab contentTest:nickName];
                _sexImgV.image = [UIImage imageNamed:@"Girls_icon_"];
            }
        }
    }else{
        if (love != nil && ![love isKindOfClass:[NSNull class]]) {
            if (love.length > 0) {
                _nickLab.text = [NSString stringWithFormat:@"%@&%@",nickName,love];
                _sexImgV.image = [UIImage imageNamed:@"fuqi"];
            }else {
                [_nickLab contentTest:nickName];
                _sexImgV.image = [UIImage imageNamed:@"Girls_icon_"];
            }
        }
    }
    
    if ([[UserManager shareManager] getCurrentUser].bcNum != nil) {
        _collectLab.text = [[UserManager shareManager] getCurrentUser].bcNum;
    }else {
        _collectLab.text = @"0";
    }
    if ([[UserManager shareManager] getCurrentUser].ccNum != nil) {
        _personLab.text = [[UserManager shareManager] getCurrentUser].ccNum;
    }else {
        _personLab.text = @"0";
    }
    if ([[UserManager shareManager] getCurrentUser].picNum != nil) {
        _picLab.text = [[UserManager shareManager] getCurrentUser].picNum;
    }else {
        _picLab.text = @"0";
    }
    
    if ([[[UserManager shareManager] getCurrentUser].waitConfirmNum isEqualToString:@"0"] || [[UserManager shareManager] getCurrentUser].waitConfirmNum == nil) {
        _confirmBtn.hidden = YES;
    }else{
        _confirmBtn.hidden = NO;
        [_confirmBtn setTitle:[[UserManager shareManager] getCurrentUser].waitConfirmNum forState:UIControlStateNormal];
    }
    
    if ([[[UserManager shareManager] getCurrentUser].waitPayNum isEqualToString:@"0"] || [[UserManager shareManager] getCurrentUser].waitPayNum == nil) {
        _unpayBtn.hidden = YES;
    }else{
        _unpayBtn.hidden = NO;
        [_unpayBtn setTitle:[[UserManager shareManager] getCurrentUser].waitPayNum forState:UIControlStateNormal];
    }
    
    if ([[[UserManager shareManager] getCurrentUser].waitServiceNum isEqualToString:@"0"] || [[UserManager shareManager] getCurrentUser].waitServiceNum == nil) {
        _serviceBtn.hidden = YES;
    }else{
        _serviceBtn.hidden = NO;
        [_serviceBtn setTitle:[[UserManager shareManager] getCurrentUser].waitServiceNum forState:UIControlStateNormal];
    }
    
    if ([[[UserManager shareManager] getCurrentUser].waitCommentNum isEqualToString:@"0"] || [[UserManager shareManager] getCurrentUser].waitCommentNum == nil) {
        _commentBtn.hidden = YES;
    }else{
        _commentBtn.hidden = NO;
        [_commentBtn setTitle:[[UserManager shareManager] getCurrentUser].waitCommentNum forState:UIControlStateNormal];
    }
    
    NSString *shouhouNum = [[UserManager shareManager] getCurrentUser].shouhouNum;
    
    if ([shouhouNum isEqualToString:@"0"] || shouhouNum == nil || [shouhouNum isKindOfClass:[NSNull class]]) {
//        [_helpBtn setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];//修改的
        _helpBtn.hidden = YES;
    }else{
        if (shouhouNum.length <= 0) {
            _helpBtn.hidden = YES;
        }else {
            _helpBtn.hidden = NO;
            [_helpBtn setTitle:shouhouNum forState:UIControlStateNormal];
        }
    }
    NSString *headStr = [CommonHelp changeStr:[[UserManager shareManager]getCurrentUser].headImg];
    
    NSData *head = [USER_DEFAULT objectForKey:HEADImageCache];
    NSData *back = [USER_DEFAULT objectForKey:BackImageCache];
    if (head) {
        _headImgV.image = [UIImage imageWithData:head];
    }
    
    if (back) {
        _backImageView.image = [UIImage imageWithData:back];
    }
    
    [_headImgV sd_setImageWithURL:[NSURL URLWithString:headStr] placeholderImage:ImageNamed(@"huazhuang_bg_.png")];
    NSString *bgStr = [CommonHelp changeStr:[[UserManager shareManager]getCurrentUser].backImg];
    [_backImageView sd_setImageWithURL:[NSURL URLWithString:bgStr] placeholderImage:ImageNamed(@"main_default.png")];
}

#pragma  mark  --  VActionViewDelegate
- (void)blackListOrCancelClick:(NSInteger)tag {
    //  移除视图
    [_actionViews hidenActionView];
    //0 是从相册选择  1是拍照
    if (self.imagePickerView == nil) {
        self.imagePickerView = [[ITTImagePickView alloc]init];
        self.imagePickerView.imgScale = 12./ 12;
        self.imagePickerView.pickDelegate = self;
    }
    //100 是照片  101是拍照
    switch (tag) {
        case 100:
        {
            ALAuthorizationStatus author = [ALAssetsLibrary authorizationStatus];
            if (author == kCLAuthorizationStatusRestricted || author ==kCLAuthorizationStatusDenied)
            {
                [CommonHelp promptMessage:@"请在iphone的\"设置-隐私-相册\" 选项中,允许爱锁访问你的相机" withCancelStr:nil withConfirmStr:@"确定"];
                return;
            }
            
            ITTDPRINT(@"照片");
            //        这里传几 就是最多选几张图片--- 这个数值应该是动态决定的
            [self.imagePickerView chooseImageFromAblum:1 withObject:self];
            [AppDelegate HideTabBar];
        }
            break;
        case 101:
        {
            ITTDPRINT(@"拍照");
            //判断有无调用相机权限
            NSString *mediaType = AVMediaTypeVideo;
            AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:mediaType];
            if(authStatus == ALAuthorizationStatusRestricted || authStatus == ALAuthorizationStatusDenied){
                [CommonHelp promptMessage:@"请在iphone的\"设置-隐私-相机\" 选项中,允许爱锁访问你的相机" withCancelStr:nil withConfirmStr:@"确定"];
                return;
            }
            [self.imagePickerView takePictureWithObject:self];
            [AppDelegate HideTabBar];
        }
            break;
        default:
            break;
    }
}

#pragma mark---ITTImagePickerViewDelegate--

- (void)getImgThumb:(UIImage *)thumbImg
{
    [AppDelegate DisplayTabBar];
    if (isAlbum) {
        self.backImageView.image = thumbImg;
    } else {
        self.headImgV.image = thumbImg;
    }
}

- (void)setNavBarStatus
{
    [self navlineViewIsHidden:YES];
    [self navBGAlpha];
}

/**
 *  如果没有登录弹出登录页面
 */
- (void)setLoginView
{
    if (!_loginVC) {
        _loginVC = [[ASLoginViewController alloc] initWithNibName:@"ASLoginViewController" bundle:nil];
        _loginVC.enterType = LoginEnterTypeMy;
    }
    [self addChildViewController:_loginVC];
    [self.view addSubview:_loginVC.view];
}

/**
 *  根据是CC还是BC设置view的样式
 */
- (void)setViewStyle
{
    if (![self getUserTypeIsBc]) {
        _confirmViewHeight.constant = 0;
        authView.hidden = YES;
    }else{
        _confirmViewHeight.constant = 52;
        authView.hidden = NO;
    }
}

- (void)loginSuccess
{
//    AppDelegate * app =(AppDelegate*)[[UIApplication sharedApplication]delegate];
//    [app.tabbarController setSelectedTabIndex:0];
//    [app.customTabBarView selectTabAtIndex:0];

    [[ASMyRequestManager shareManager] cancelAllRequest];
    [[ASMainRequestManager shareManager]cancelAllRequest];
    
    [self performSelector:@selector(senderRequest) withObject:nil afterDelay:0.02];
    
    // 滑動到position的位置
    CGPoint position = CGPointMake(0, 0);
    [_scrollView setContentOffset:position animated:YES];
   
}

- (void)setUpNotification
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginSuccess) name:@"Login" object:nil];
}

/**
 *  收藏店铺  收藏新人  我的图片点击事件
 *
 *  @param sender 
 */
- (IBAction)myBtnClick:(UIButton *)sender
{

}

/**
 *  我的订单相关按钮
 *
 *  @param sender 
 */
- (IBAction)orderBtnClick:(UIButton *)sender
{
    NSString *state = @"";
    switch (sender.tag) {
        case 501://待确认
        {
            state = @"1";
        }
            break;
        case 502://待付款
        {
            state = @"2";
        }
            break;
        case 503://待服务
        {
            state = @"3";
        }
            break;
        case 504://待评价
        {
            state = @"4";
        }
            break;
        case 505://售后
        {
        }
            break;
    }
    
}

/**
 *  订单 个人主页 认证信息 我的账户 个人信息 设置 等的点击事件
 *
 *  @param sender
 */
- (IBAction)otherBtnClick:(UIButton *)sender
{
    switch (sender.tag) {
    }
}

- (void)sendRequest
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic safeString:[[UserManager shareManager] getCurrentUser].userId ForKey:@"appUserId"];
    __weak ASMyViewController *weak = self;
    [[ASMyRequestManager shareManager] requestMyWithParam:dic withIndicatorView:nil withCancelRequestID:@"My" withHttpMethod:kHTTPMethodPost onRequestFinish:^(MKNetworkOperation *operation) {
        if (operation.isSuccees) {
            NSString *authStatus = [operation.resultDic objectForKey:@"authStatus"];
            NSString *bcNum = [operation.resultDic objectForKey:@"bcNum"];
            NSString *ccNum = [operation.resultDic objectForKey:@"ccNum"];
            NSString *picNum = [operation.resultDic objectForKey:@"picNum"];
            NSString *waitCommentNum = [operation.resultDic objectForKey:@"waitCommentNum"];
            NSString *waitConfirmNum = [operation.resultDic objectForKey:@"waitConfirmNum"];
            NSString *waitPayNum = [operation.resultDic objectForKey:@"waitPayNum"];
            NSString *waitServiceNum = [operation.resultDic objectForKey:@"waitServiceNum"];
            NSString *shouhouNum = [operation.resultDic objectForKey:@"shouhouNum"];
            NSString *loveNickName = [operation.resultDic objectForKey:@"loverNickname"];
            NSString *sex = [CommonHelp changeStr:[[UserManager shareManager] getCurrentUser].gender];
            
            NSString *nickName = [[UserManager shareManager] getCurrentUser].nickname;
            
            if ([sex isEqualToString:@"0"]) {//男
                weak.sexImgV.image = [UIImage imageNamed:@"boy_"];
                [weak.nickLab contentTest:nickName];
                if (loveNickName != nil && ![loveNickName isKindOfClass:[NSNull class]]) {
                    if (loveNickName.length > 0) {
                        weak.nickLab.text = [NSString stringWithFormat:@"%@&%@",nickName,loveNickName];
                        weak.sexImgV.image = [UIImage imageNamed:@"fuqi"];
                    }
                }
            }else{
                weak.sexImgV.image = [UIImage imageNamed:@"Girls_icon_"];
                if (loveNickName != nil && ![loveNickName isKindOfClass:[NSNull class]]) {
                    if (loveNickName.length > 0) {
                        weak.nickLab.text = [NSString stringWithFormat:@"%@&%@",nickName,loveNickName];
                        weak.sexImgV.image = [UIImage imageNamed:@"fuqi"];
                    }
                }
            }
            
            if ([authStatus isEqualToString:@"2"]) {
                authLab.text = @"已通过认证";
            } else if([authStatus isEqualToString:@"1"]){
                authLab.text = @"未认证";
            }else if([authStatus isEqualToString:@"3"]){
                authLab.text = @"认证不通过";
            }
            
            weak.collectLab.text = bcNum;
            weak.personLab.text = ccNum;
            weak.picLab.text = picNum;
            if ([waitConfirmNum isEqualToString:@"0"] || waitCommentNum == nil) {
                weak.confirmBtn.hidden = YES;
            }else{
                weak.confirmBtn.hidden = NO;
                [weak.confirmBtn setTitle:waitConfirmNum forState:UIControlStateNormal];
            }
            
            if ([waitPayNum isEqualToString:@"0"]|| waitPayNum == nil) {
                weak.unpayBtn.hidden = YES;
            }else{
                weak.unpayBtn.hidden = NO;
                [weak.unpayBtn setTitle:waitPayNum forState:UIControlStateNormal];
            }
            
            if ([waitServiceNum isEqualToString:@"0"]|| waitServiceNum == nil) {
                weak.serviceBtn.hidden = YES;
            }else{
                weak.serviceBtn.hidden = NO;
                [weak.serviceBtn setTitle:waitServiceNum forState:UIControlStateNormal];
            }
            
            if ([waitCommentNum isEqualToString:@"0"]|| waitCommentNum == nil) {
                weak.commentBtn.hidden = YES;
            }else{
                weak.commentBtn.hidden = NO;
                [weak.commentBtn setTitle:waitCommentNum forState:UIControlStateNormal];
            }
            
            if ([shouhouNum isEqualToString:@"0"]|| shouhouNum == nil) {
//                [_helpBtn setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
                weak.helpBtn.hidden = YES;
            }else {
                weak.helpBtn.hidden = NO;
                [weak.helpBtn setTitle:shouhouNum forState:UIControlStateNormal];
            }
            
            NSMutableDictionary *savedic = [NSMutableDictionary dictionary];
            [savedic safeString:authStatus ForKey:@"authStatus"];
            [savedic safeString:bcNum ForKey:@"bcNum"];
            [savedic safeString:ccNum ForKey:@"ccNum"];
            [savedic safeString:picNum ForKey:@"picNum"];
            [savedic safeString:waitCommentNum ForKey:@"waitCommentNum"];
            [savedic safeString:waitConfirmNum ForKey:@"waitConfirmNum"];
            [savedic safeString:waitPayNum ForKey:@"waitPayNum"];
            [savedic safeString:waitServiceNum ForKey:@"waitServiceNum"];
            [savedic safeString:shouhouNum ForKey:@"shouhouNum"];
           
            [[ITTDataCacheManager sharedManager] updateObject:[UserModel class] forKey:USER_INFO_KEY byPropertyDic:savedic];
        }
    } onRequestFailed:^(MKNetworkOperation *operation, NSError *error) {
        
    }];
}

/**
 *  请求上传图片的token
 */
- (void)requestQiniuToken
{
    __weak ASMyViewController *weakSelf = self;
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic safeString:@"ionly-other" ForKey:@"bucketName"];
    [[ASMainRequestManager shareManager] requestQiniuTokenWithParam:dic withIndicatorView:nil withCancelRequestID:@"CCToken" withHttpMethod:kHTTPMethodPost onRequestFinish:^(MKNetworkOperation *operation) {
        if (operation.isSuccees) {
            weakSelf.qiniuToken = [operation.resultDic objectForKey:@"uptoken"];
        }
    } onRequestFailed:^(MKNetworkOperation *operation, NSError *error) {
        
    }];
}

- (void)changeImgRequest:(NSString *)key
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic safeString:[[UserManager shareManager] getCurrentUser].userId ForKey:@"appUserId"];
    if (isAlbum) {
        [dic safeString:key ForKey:@"backImg"];
    }else{
        [dic safeString:key ForKey:@"headImg"];
    }
    [[ASMyRequestManager shareManager] requestSetWithParam:dic withIndicatorView:nil withCancelRequestID:@"SetHead" withHttpMethod:kHTTPMethodPost onRequestFinish:^(MKNetworkOperation *operation) {
        if (operation.isSuccees) {
            
            if (isAlbum) {
                [self.backImageView sd_setImageWithPreviousCachedImageWithURL:[NSURL URLWithString:[[operation.resultDic objectForKey:@"appUser"] objectForKey:@"backImg"]] andPlaceholderImage:ImageNamed(@"main_default.png") options:SDWebImageRefreshCached progress:^(NSInteger receivedSize, NSInteger expectedSize) {
                    
                } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                    if (!_backImageView.image) {
                        _backImageView.image = ImageNamed(@"main_default.png");
                    }
                    NSData *imageData = UIImagePNGRepresentation(self.backImageView.image);
                    [USER_DEFAULT setObject:imageData forKey:BackImageCache];
                }];
                
            } else {
                
                [self.headImgV sd_setImageWithPreviousCachedImageWithURL:[NSURL URLWithString:[[operation.resultDic objectForKey:@"appUser"] objectForKey:@"headImg"]] andPlaceholderImage:ImageNamed(@"huazhuang_bg_.png") options:SDWebImageRefreshCached progress:^(NSInteger receivedSize, NSInteger expectedSize) {
                    
                } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                    if (!_headImgV.image) {
                        _headImgV.image = ImageNamed(@"huazhuang_bg_.png");
                    }
                    
                    NSData *imageData = UIImagePNGRepresentation(self.backImageView.image);
                    [USER_DEFAULT setObject:imageData forKey:HEADImageCache];
                }];
            }
            [[ITTDataCacheManager sharedManager] updateObject:[UserModel class] forKey:USER_INFO_KEY byPropertyDic:[operation.resultDic objectForKey:@"appUser"]];
            
//            [DATA_CATHE addObject:_materialArr forKey:MainMaterialImageKey];
//            [DATA_CATHE doSave];
        }
    
    } onRequestFailed:^(MKNetworkOperation *operation, NSError *error) {
   }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
