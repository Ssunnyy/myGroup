//
//  YXBaseOperation.h
//  YiXin
//
//  Created by keke on 14/11/20.
//  Copyright (c) 2014年 com.yixin. All rights reserved.
//

#import "ITTMKNetWorkOperation.h"
#import "CommonHelp.h"
//#import "ITTDataEnvironment.h"
#import "NSString+Base64.h"
#include "edcode.h"

@interface YXBaseOperation : ITTMKNetWorkOperation

@end
