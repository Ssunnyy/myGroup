//
//  YXBaseEngine.h
//  YiXin
//
//  Created by keke on 14/11/20.
//  Copyright (c) 2014年 com.yixin. All rights reserved.
//

#import "ITTMKNetworkEngine.h"
#import "ITTMKNetworkOperation.h"

@interface YXBaseEngine : ITTMKNetworkEngine
@end
