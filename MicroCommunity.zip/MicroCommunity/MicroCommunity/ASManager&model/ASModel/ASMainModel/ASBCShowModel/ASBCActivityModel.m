//
//  ASBCActivityModel.m
//  ITotem
//
//  Created by adims on 15/4/23.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import "ASBCActivityModel.h"

@implementation ASBCActivityModel

- (NSDictionary *)attributeMapDictionary {
    
    return @{
             @"activityIcon":@"activityIcon",
             @"activityImg":@"activityImg",
             @"activityImg":@"activityImg",
             @"activityName":@"activityName",
             @"activityType":@"activityType",
             @"activityUrl":@"activityUrl",
             @"endTime":@"endTime",
             @"ids":@"id",
             @"showIndex":@"showIndex",
             @"showOrder":@"showOrder",
             @"startTime":@"startTime",
             };
}

@end
