//
//  ASMainBCCCModel.m
//  ITotem
//
//  Created by qiuyan on 15-3-14.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import "ASMainBCCCModel.h"

@implementation ASMainBCCCModel

- (NSDictionary *)attributeMapDictionary{
    
    return @{
             @"workYear":@"workYear",
             @"authStatus":@"authStatus",
             @"serviceRemote":@"serviceRemote",
             @"serviceDoor":@"serviceDoor",
             @"praiseNum":@"praiseNum",
             @"jobId":@"jobId",
             @"uid":@"id",
             @"collected":@"collected",
             @"bornYear":@"bornYear",
             @"badReviewNum":@"badReviewNum",
             @"appUserId":@"appUserId",
             @"marryDate":@"marryDate",
             @"collectNum":@"collectNum",
             @"loverNickname":@"loverNickname",
             @"user":@"user",
             @"collec":@"collec",
             @"jobName":@"jobName",
             @"fullGradeCount":@"fullGradeCount",
             @"halfGradeCount":@"halfGradeCount",
             @"noneGradeCount":@"noneGradeCount",
             @"joinActivity":@"joinActivity"
            };
}

@end
