//
//  ASMainAdModel.m
//  ITotem
//
//  Created by qiuyan on 15-3-11.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import "ASMainAdModel.h"

@implementation ASMainAdModel

- (NSDictionary *)attributeMapDictionary{
    
    return @{
             @"activityIcon":@"activityIcon",
             @"activityImg":@"activityImg",
             @"activityName":@"activityName",
             @"activityType":@"activityType",
             @"activityUrl":@"activityUrl",
             @"endTime":@"endTime",
             @"ids":@"id",
             @"showIndex":@"showIndex",
             @"showOrder":@"showOrder",
             @"startTime":@"showOrder",
             };
}


@end
