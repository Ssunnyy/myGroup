//
//  ASMaterialThirdModel.m
//  ITotem
//
//  Created by adims on 15/3/14.
//  Copyright (c) 2015年 qiuyan. All rights reserved.
//

#import "ASMaterialThirdModel.h"

@implementation ASMaterialThirdModel


- (NSDictionary *)attributeMapDictionary {
    
    return @{
             @"appUserId":@"appUserId",
             @"collect":@"collect",
             @"favCount":@"favCount",
             @"desc":@"description",
             @"favCount":@"favCount",
             @"ids":@"id",
             @"materialImg":@"materialImg",
             @"materialPreviewImg":@"materialPreviewImg",
             @"materialName":@"materialName",
             @"secondMaterial":@"secondMaterial",
             @"secondMaterialId":@"secondMaterialId",
             @"showOrder":@"showOrder",
             @"uploadTime":@"uploadTime",
             @"uploadType":@"uploadType",
             };
}

@end
